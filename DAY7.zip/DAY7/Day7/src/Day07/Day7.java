/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Day07;

/**
 *
 * @author macstudent
 */
public class Day7 {
    
    public static void main(String[] args){
        
        Triangle t1= new Triangle(20,30);
        t1.x=40;
        t1.draw();
        t1.display();
    }
    
}
