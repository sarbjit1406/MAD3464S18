/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylisttest;

import java.util.Comparator;

/**
 *
 * @author macstudent
 */
public class Books {
    int bookID;
    String bookTittle;
    int bookRating;
    
    Books(){
        this.bookID=0;
        this.bookTittle="Unknown";
        this.bookRating=0;
    }
    
    Books(int bookID, String bookTittle, int bookRating){
          this.bookID=bookID;
        this.bookTittle=bookTittle;
        this.bookRating=bookRating;
    }
    void setID(int ID){
        this.bookID=bookID;   
    }
    void getID(int ID){
   this.bookID= ID;
    }
    int getID(){
        return this.bookID;
    }
    void setTittle(String Tittle){
        this.bookTittle=bookTittle;
    }
    String getTittle(){
        return this.bookTittle;
    }
    void getRating(int rate){
        this.bookRating= rate;
    }
    int getRating(){
        return this.bookRating;
    }
    void displayInfo(){
        System.out.println("bookId: " + this.bookID +
                "\n Book Tittle: " + this.bookTittle +
                "\n Book Rating: " + bookRating);
    }
            
           
}
//To sort the books in library
// "Comparator" interface is pre-placed in java

class bookTittleComparator implements Comparator<Books>{
    
    @Override
    public int compare(Books b1, Books b2) {
        return b1.bookTittle.compareToIgnoreCase(b2.bookTittle);
    }

}
    
 class bookRatingComparator implements Comparator<Books>{
     @Override
     public int  compare(Books b1, Books b2){
         if (b1.bookRating == b2.bookRating)
             return 0;
         else if(b1.bookRating < b2.bookRating)
             return 1;
         else
             return -1;}
         
}
         