/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylisttest;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author macstudent
 */
public class ArrayListTest {
    public static void main(String[] args){
//       * Creating an array
//          Example
//        int [] productName= new int[6];

//        *Creating list of array to reduce the issue of memory allocation in array
          
    ArrayList<String>ProductsName= new ArrayList<String>();
    
    ProductsName.add("Projector");
    ProductsName.add("Excel");
    ProductsName.add("Contigo");
    ProductsName.add("Apple");
    
//    To add oracle at 2nd place

    ProductsName.add(2,"Oracle");
    
    for(String sarb : ProductsName){
         System.out.println(sarb);
    }
    System.out.println("=======");
    
//    To check the information of product and To removing a product
       if(ProductsName.contains("Oracle")){
            ProductsName.remove("Oracle");
       }else{
           System.err.println("Buy oracle first");;
       }   
    
     for(String sarb : ProductsName){
         System.out.println(sarb);
     }
     Collections.sort(ProductsName);
     System.out.println("=======");
     for(String sarb : ProductsName){
         System.out.println(sarb);
     }
//     Array <classname> (name) = new object
     ArrayList<Books> library = new ArrayList<Books> ();
    Books book1 = new Books (101, "The sky is falling", 9);
    Books book2 = new Books (102, "Pride and Prejudice", 5);
    Books book3 = new Books(103, "The monk", 7);
    Books book4 = new Books(104, "Courage", 12);
    
    library.add(book1);
    library.add(book2);
    library.add(book3);
    library.add(book4);
    
    for(Books bk : library){
        bk.displayInfo();
    }
//     to check the counting of books in library by using size operator  
    System.out.println("No of books in library : " + library.size());
    
    if(library.contains(book2)){
        library.remove(book2);
    }
    
    System.out.println("No of books in library : " + library.size());
    
    library.add(2, new Books(120, "Pearls", 11));
    for(Books bk : library){
        bk.displayInfo();
    }
    
    Collections.sort(library, new bookTittleComparator());
    for(Books bk : library){
        bk.displayInfo();
  }   
    Collections.sort(library, new bookRatingComparator());
    for(Books bk : library){
        bk.displayInfo();
    
}
    }
}